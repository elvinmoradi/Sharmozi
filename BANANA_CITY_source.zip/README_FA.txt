BANANA CITY | شهر موزی — شهر تو، قوانین تو!

اجرا روی اندروید:
1) فایل BANANA_CITY.html را در گوشی ذخیره کن و با Chrome باز کن.
2) «Add to Home screen» را بزن و گوشی را عمودی بگیر. اگر کند بود: گوشی ← تنظیمات ← کیفیت «کم».
اجرا روی کامپیوتر: همان فایل را در Chrome باز کن (WASD، ماوس، E تعامل، F ماشین، P گوشی، M نقشه، Shift نیترو).

پوشه src: کد منبع بخش‌بخش (بدون مدل‌های سنگین). برای ساخت دوباره، فایل build.py مدل‌ها را از پوشه models/opt می‌خواند.

مجوزها:
- Car Concept: Eric Chadwick, CC-BY 4.0 (Khronos glTF Sample Assets)
- Ferrari 458: vicent091036, CC-BY 4.0 (three.js examples)
- Soldier: Mixamo (three.js examples)   - CesiumMan: Cesium, CC-BY 4.0
- Three.js: MIT
- مدل‌های سمند، پژو ۲۰۶، پژو پارس، پراید، دنا و فضای داخلی ساختمان‌ها: ساخت اصلی همین پروژه
- مخازن Eko Streets و Samand3DViewer بدون مجوز مشخص بودند و هیچ کد یا مدلی از آن‌ها وارد پروژه نشده است.
- TorqueVerse 3D (MIT): فقط ایده‌ی رد لاستیک و پد سرعت الهام گرفته شد؛ کد از نو نوشته شد.
